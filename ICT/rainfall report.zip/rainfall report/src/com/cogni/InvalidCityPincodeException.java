package com.cogni;
@SuppressWarnings("serial")
public class InvalidCityPincodeException extends Exception {
		public InvalidCityPincodeException(String s)
	{
		super(s);
	}
}